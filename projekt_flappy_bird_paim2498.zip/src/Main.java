void main() {
    new GameWindow();
}
